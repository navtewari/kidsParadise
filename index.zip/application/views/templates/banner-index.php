<!-- banner -->
    <div class="banner-agile">
        <ul class="slider">
            <li class="active">
                <div class="banner-w3ls-1">
                </div>
            </li>
            <li>
                <div class="banner-w3ls-2">
                </div>
            </li>
            <li>
                <div class="banner-w3ls-3">
                </div>
            </li>
            <li>
                <div class="banner-w3ls-4">
                </div>
            </li>
            <li class="prev">
                <div class="banner-w3ls-5">
                </div>
            </li>
        </ul>
        <ul class="pager">
            <li data-index="0" class="active"></li>
            <li data-index="1"></li>
            <li data-index="2"></li>
            <li data-index="3"></li>
            <li data-index="4"></li>
        </ul>
        <div class="banner-text-posi-w3ls">
            <div class="banner-text-whtree">
                <h3 class="text-capitalize text-white p-4">your bright future
                    <b>is our mission!</b>
                </h3>
                <p class="px-4 py-3 text-dark">Better education for better world!</p>                
            </div>
        </div>

        <!-- navigation -->
        <?php $this->load->view('templates/menu');?>
        <!-- //navigation -->
    </div>
    <!-- //banner -->